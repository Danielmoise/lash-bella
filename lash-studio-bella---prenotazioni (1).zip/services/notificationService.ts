import { Appointment } from '../types';

const WEBHOOK_URL = 'https://hook.eu2.make.com/g41m4fubukk9nnwnne7wtao1lrcdeg4e';

export const sendBookingConfirmation = async (appointment: Appointment): Promise<void> => {
    // Un errore 400 (Bad Request) spesso indica che il server (webhook) non ha compreso il formato della richiesta.
    // Questo può accadere se il webhook non è configurato per gestire oggetti JSON annidati.
    // Appiattiamo la struttura dei dati per renderla più semplice e compatibile.
    const payload = {
        service_name: appointment.service.name,
        service_description: appointment.service.description,
        service_duration: appointment.service.duration,
        date: appointment.date,
        time: appointment.time,
        client_firstName: appointment.userInfo.firstName,
        client_lastName: appointment.userInfo.lastName,
        client_email: appointment.userInfo.email,
        client_phone: appointment.userInfo.phone,
    };

    try {
        const response = await fetch(WEBHOOK_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        });

        if (!response.ok) {
            const responseBody = await response.text();
            console.error('Dettagli dell\'errore dal webhook:', responseBody);
            // Includi il corpo della risposta nell'errore per un debug più facile
            throw new Error(`Errore dal webhook (${response.status}): ${responseBody || response.statusText}`);
        }
        
        console.log("Dati della prenotazione inviati con successo al webhook.");

    } catch (error) {
        console.error("Impossibile inviare i dati al webhook:", error);
        // Rilancia l'errore per permettere al chiamante (App.tsx) di gestirlo.
        // In questo caso, App.tsx mostrerà un alert all'utente.
        throw error;
    }
};
