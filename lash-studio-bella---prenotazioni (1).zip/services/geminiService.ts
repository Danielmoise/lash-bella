
import { GoogleGenAI, Type } from '@google/genai';
import { Appointment } from '../types';

if (!process.env.API_KEY) {
    console.warn("La chiave API di Gemini non è configurata. Le funzionalità AI saranno disabilitate.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        clientEmailBody: {
            type: Type.STRING,
            description: "Il corpo dell'email di conferma per il cliente, in italiano.",
        },
        ownerEmailBody: {
            type: Type.STRING,
            description: "Il corpo dell'email di notifica per il proprietario del salone, in italiano.",
        },
    },
    required: ["clientEmailBody", "ownerEmailBody"],
};

export const generateNotificationEmails = async (appointment: Appointment): Promise<{ clientEmailBody: string; ownerEmailBody: string; }> => {
    if (!process.env.API_KEY) {
        console.log("Simulazione chiamata API Gemini a causa della mancanza della chiave API.");
        return {
            clientEmailBody: `(Simulato) Gentile ${appointment.userInfo.firstName}, la sua prenotazione per ${appointment.service.name} il ${appointment.date} alle ${appointment.time} è confermata. La preghiamo di presentarsi senza trucco sugli occhi. A presto!`,
            ownerEmailBody: `(Simulato) Nuova prenotazione: ${appointment.service.name} per ${appointment.userInfo.firstName} ${appointment.userInfo.lastName} il ${appointment.date} alle ${appointment.time}.`
        };
    }
    
    const { service, date, time, userInfo } = appointment;
    
    const prompt = `
        Sei un assistente virtuale per un salone di bellezza di lusso chiamato 'Lash Studio Bella'.
        Genera due testi per email di notifica in formato JSON, seguendo lo schema fornito.
        I testi devono essere in italiano, professionali, e con un tono femminile ed elegante.

        Dettagli della prenotazione:
        - Nome Cliente: ${userInfo.firstName} ${userInfo.lastName}
        - Servizio: ${service.name}
        - Data: ${date}
        - Ora: ${time}

        Istruzioni per i contenuti:
        1.  'clientEmailBody': Scrivi un'email di conferma amichevole e calorosa per il cliente. Includi tutti i dettagli della prenotazione. Aggiungi un importante promemoria: "Le ricordiamo gentilmente di presentarsi all'appuntamento con la zona occhi completamente struccata per garantire la migliore riuscita del trattamento." Termina con un saluto cordiale.
        2.  'ownerEmailBody': Scrivi un riassunto conciso e chiaro per la proprietaria del salone. Elenca i dettagli chiave della nuova prenotazione.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            },
        });
        
        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);
        
        return parsedJson;

    } catch (error) {
        console.error("Errore durante la chiamata all'API Gemini:", error);
        throw new Error("Impossibile generare le notifiche email.");
    }
};
