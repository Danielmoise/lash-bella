
import { Appointment } from '../types';
import { OPENING_HOUR, CLOSING_HOUR, SLOT_INTERVAL } from '../constants';

// Helper per convertire l'ora HH:mm in minuti totali dal giorno
const timeToMinutes = (time: string): number => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
};

// Helper per convertire i minuti in formato ora HH:mm
const minutesToTime = (minutes: number): string => {
    const h = Math.floor(minutes / 60).toString().padStart(2, '0');
    const m = (minutes % 60).toString().padStart(2, '0');
    return `${h}:${m}`;
};

export const getAvailableSlots = (
    serviceDuration: number, 
    existingAppointments: Appointment[], 
    day: Date
): string[] => {
    const availableSlots: string[] = [];
    const openingTime = OPENING_HOUR * 60;
    const closingTime = CLOSING_HOUR * 60;

    const todayAppointments = existingAppointments
        .filter(app => app.date === day.toLocaleDateString('it-IT'))
        .map(app => ({
            start: timeToMinutes(app.time),
            end: timeToMinutes(app.time) + app.service.duration,
        }));
    
    // Non mostrare orari passati
    const now = new Date();
    let currentTime = openingTime;
    if (day.toDateString() === now.toDateString()) {
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      // Arrotonda al prossimo slot di 30 minuti
      currentTime = Math.max(openingTime, Math.ceil(currentMinutes / SLOT_INTERVAL) * SLOT_INTERVAL);
    }

    for (let slotStart = currentTime; slotStart < closingTime; slotStart += SLOT_INTERVAL) {
        const slotEnd = slotStart + serviceDuration;

        if (slotEnd > closingTime) {
            break; // L'appuntamento finirebbe dopo l'orario di chiusura
        }

        const isOverlapping = todayAppointments.some(app => 
            (slotStart < app.end && slotEnd > app.start)
        );

        if (!isOverlapping) {
            availableSlots.push(minutesToTime(slotStart));
        }
    }

    return availableSlots;
};
