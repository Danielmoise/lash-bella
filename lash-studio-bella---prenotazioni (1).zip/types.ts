
export interface Service {
    id: number;
    name: string;
    description: string;
    duration: number; // in minuti
}

export interface UserInfo {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
}

export interface Appointment {
    service: Service;
    date: string;
    time: string;
    userInfo: UserInfo;
}

export enum Step {
    SERVICE_SELECTION,
    DATETIME_PICKER,
    USER_INFO,
    CONFIRMATION
}
