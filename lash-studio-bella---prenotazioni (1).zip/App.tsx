
import React, { useState, useCallback, useMemo } from 'react';
import { Service, Appointment, UserInfo, Step } from './types';
import { SERVICES, STEPS } from './constants';
import ServiceSelector from './components/ServiceSelector';
import DateTimePicker from './components/DateTimePicker';
import UserInfoForm from './components/UserInfoForm';
import Confirmation from './components/Confirmation';
import { generateNotificationEmails } from './services/geminiService';
import { sendBookingConfirmation } from './services/notificationService';

const EyelashIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-pink-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 12c.5 2 1.5 3 4 3s3.5-1 4-3" />
    </svg>
);


export default function App() {
    const [currentStep, setCurrentStep] = useState<Step>(Step.SERVICE_SELECTION);
    const [selectedService, setSelectedService] = useState<Service | null>(null);
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [selectedTime, setSelectedTime] = useState<string | null>(null);
    const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [bookingError, setBookingError] = useState<string | null>(null);
    
    // Simula appuntamenti esistenti per la giornata odierna
    const [appointments, setAppointments] = useState<Appointment[]>([
        { service: SERVICES[1], date: new Date().toLocaleDateString('it-IT'), time: '10:00', userInfo: {firstName: 'Jane', lastName: 'Doe', email: 'jane.d@example.com', phone: '555-1234'} },
        { service: SERVICES[0], date: new Date().toLocaleDateString('it-IT'), time: '14:00', userInfo: {firstName: 'Mary', lastName: 'Smith', email: 'mary.s@example.com', phone: '555-5678'} },
    ]);

    const finalAppointment = useMemo(() => {
        if (selectedService && selectedTime && userInfo) {
            return {
                service: selectedService,
                date: selectedDate.toLocaleDateString('it-IT'),
                time: selectedTime,
                userInfo: userInfo
            };
        }
        return null;
    }, [selectedService, selectedDate, selectedTime, userInfo]);

    const handleServiceSelect = (service: Service) => {
        setSelectedService(service);
        setCurrentStep(Step.DATETIME_PICKER);
    };

    const handleTimeSelect = (time: string) => {
        setSelectedTime(time);
        setCurrentStep(Step.USER_INFO);
    };

    const handleUserInfoSubmit = useCallback(async (info: UserInfo) => {
        if (!selectedService || !selectedTime) return;
        
        setIsLoading(true);
        setBookingError(null);

        const newAppointment: Appointment = {
            service: selectedService,
            date: selectedDate.toLocaleDateString('it-IT'),
            time: selectedTime,
            userInfo: info,
        };
        
        try {
            console.log("Generazione notifiche email con Gemini...");
            const emails = await generateNotificationEmails(newAppointment);
            console.log("--- Email per il Cliente ---");
            console.log(emails.clientEmailBody);
            console.log("----------------------------");
            console.log("--- Email per il Proprietario ---");
            console.log(emails.ownerEmailBody);
            console.log("-------------------------------");

            console.log("Invio dati prenotazione al webhook...");
            await sendBookingConfirmation(newAppointment);
            console.log("Dati inviati con successo.");

            setUserInfo(info);
            setAppointments(prev => [...prev, newAppointment]);
            setCurrentStep(Step.CONFIRMATION);

        } catch (error) {
            console.error("Errore durante la conferma della prenotazione:", error);
            const errorMessage = error instanceof Error ? error.message : "Si è verificato un errore sconosciuto.";
            
            const userFriendlyMessage = errorMessage.toLowerCase().includes("webhook is temporarily disabled")
              ? "Siamo spiacenti, il sistema di conferma prenotazioni è fuori servizio. La sua prenotazione non può essere completata. La preghiamo di riprovare più tardi o di contattare direttamente il salone."
              : `Si è verificato un errore imprevisto: ${errorMessage}. Riprovi più tardi.`;

            setBookingError(userFriendlyMessage);
        } finally {
            setIsLoading(false);
        }
    }, [selectedService, selectedDate, selectedTime]);

    const handleBack = () => {
        setBookingError(null);
        if (currentStep === Step.DATETIME_PICKER) {
            setCurrentStep(Step.SERVICE_SELECTION);
            setSelectedService(null);
        } else if (currentStep === Step.USER_INFO) {
            setCurrentStep(Step.DATETIME_PICKER);
            setSelectedTime(null);
        }
    };
    
    const handleNewBooking = () => {
        setCurrentStep(Step.SERVICE_SELECTION);
        setSelectedService(null);
        setSelectedDate(new Date());
        setSelectedTime(null);
        setUserInfo(null);
        setBookingError(null);
    };
    
    const renderStep = () => {
        switch (currentStep) {
            case Step.SERVICE_SELECTION:
                return <ServiceSelector services={SERVICES} onSelect={handleServiceSelect} />;
            case Step.DATETIME_PICKER:
                return <DateTimePicker 
                    service={selectedService!} 
                    existingAppointments={appointments} 
                    onSelect={handleTimeSelect}
                    onBack={handleBack}
                    selectedDate={selectedDate}
                    onDateChange={setSelectedDate}
                />;
            case Step.USER_INFO:
                return <UserInfoForm 
                    onSubmit={handleUserInfoSubmit} 
                    isLoading={isLoading} 
                    onBack={handleBack}
                    error={bookingError}
                />;
            case Step.CONFIRMATION:
                return <Confirmation appointment={finalAppointment!} onNewBooking={handleNewBooking} />;
            default:
                return <div>Passo non trovato</div>;
        }
    };

    return (
        <div className="min-h-screen flex flex-col items-center p-4 sm:p-6 md:p-8">
            <header className="text-center mb-10">
                <div className="flex justify-center items-center gap-4">
                    <EyelashIcon />
                    <h1 className="text-4xl md:text-5xl font-serif text-gray-800">Lash Studio Bella</h1>
                    <EyelashIcon />
                </div>
                <p className="text-pink-600 mt-2">La tua oasi di bellezza per ciglia perfette</p>
            </header>
            <main className="w-full max-w-2xl bg-white rounded-2xl shadow-xl p-6 md:p-10 border border-pink-100">
                <div className="mb-6">
                    <h2 className="text-2xl font-bold text-center text-pink-800">{STEPS[currentStep].title}</h2>
                    <p className="text-center text-gray-500">{STEPS[currentStep].description}</p>
                </div>
                {renderStep()}
            </main>
             <footer className="text-center mt-8 text-gray-500 text-sm">
                <p>&copy; {new Date().getFullYear()} Lash Studio Bella. Tutti i diritti riservati.</p>
            </footer>
        </div>
    );
}