
import { Service, Step } from './types';

export const SERVICES: Service[] = [
    { id: 1, name: 'Ciglia 2D', description: 'Un look naturale ma definito, con due extension per ciglia naturale.', duration: 120 },
    { id: 2, name: 'Ciglia 3D', description: 'Più volume e intensità per uno sguardo magnetico.', duration: 60 },
    { id: 3, name: "Ciglia 4D 'Volume Russo'", description: 'Massimo volume per un effetto spettacolare e audace.', duration: 180 },
];

export const STEPS = {
    [Step.SERVICE_SELECTION]: {
        title: "Passo 1: Scegli il Tuo Trattamento",
        description: "Seleziona il servizio di extension ciglia che desideri."
    },
    [Step.DATETIME_PICKER]: {
        title: "Passo 2: Seleziona Data e Ora",
        description: "Scegli un orario disponibile per il tuo appuntamento oggi."
    },
    [Step.USER_INFO]: {
        title: "Passo 3: I Tuoi Dati",
        description: "Manca poco! Inserisci le tue informazioni per completare la prenotazione."
    },
    [Step.CONFIRMATION]: {
        title: "Prenotazione Confermata!",
        description: "Grazie per aver scelto Lash Studio Bella. Ti aspettiamo!"
    }
};

export const OPENING_HOUR = 9;
export const CLOSING_HOUR = 18;
export const SLOT_INTERVAL = 30; // minuti
